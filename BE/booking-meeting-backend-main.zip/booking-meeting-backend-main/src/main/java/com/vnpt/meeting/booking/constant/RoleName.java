package com.vnpt.meeting.booking.constant;

public enum RoleName {
    ROLE_USER,
    ROLE_MODERATOR,
    ROLE_ADMIN
}
