package com.vnpt.meeting.booking.repository;

import org.springframework.stereotype.Repository;

@Repository
public class BookingRepositoryCustom {

}
