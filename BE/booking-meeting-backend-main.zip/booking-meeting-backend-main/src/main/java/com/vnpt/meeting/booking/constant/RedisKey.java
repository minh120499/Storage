package com.vnpt.meeting.booking.constant;

public class RedisKey {
    public final static String ACCESS_TOKENS_PREFIX = "booking_access_tokens_";
    public final static String REFRESH_TOKEN_PREFIX = "booking_refresh_token_";
}
